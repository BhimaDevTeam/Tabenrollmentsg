import React, { useState, useEffect, useMemo } from "react";
import axios from "axios";
import {
  Container,
  CssBaseline,
  Button,
  Box,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Modal,
  Fade,
} from "@mui/material";

import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Membershipdetails from "./MembershipDetails";
import Subscriberdetails from "./SubscriberDetails";
import Nomineedeatils from "./NomineeDeatils";
import Paymentdetails from "./PaymentDetails";
import GuardaianDetails from "./GuardaianDetails";
import { Link, useLocation, useNavigate } from "react-router-dom";
import "./Mypage.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import { calculateAge } from "../PickDate/DateUtils";

import CameraIcon from '@mui/icons-material/Camera';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Card } from "react-bootstrap";
import { useSelector } from "react-redux";
import { Drafttabledb } from "../../apiurl";
import WebCamComponent from "./WebCamComponent";
import UploadDocument from "./UploadFile";

import Paymentgateway from "./Paymentgateway";

// import { ErrorSharp } from '@mui/icons-material';
const Mypage = () => {
  const { selectedCustomerID } = useSelector((state) => state.customer);
  
  const location = useLocation();
  const navigate = useNavigate();
  const {
    customerData,
    phoneNo,
    branch,
    selectedId,
    selectedOption,
    newSubscriber,
    aadharverified,
    aadharNo
  } =
    location.state && typeof location.state === "object" ? location.state : {};

  const [expanded, setExpanded] = useState("subscriber-header");
  const [subscriberData, setSubscriberData] = useState({});
  const [phone, setPhone] = useState(phoneNo || "");
  const [membershipData, setMembershipData] = useState({});
  const [nomineeData, setNomineeData] = useState({});
  const [bankData, setBankData] = useState({});
  const [guardaianData, setGuardianData] = useState({});
  const [showGuardianDetails, setShowGuardianDetails] = useState(false);
  const [saveDraftTrigger, setSaveDraftTrigger] = useState(false);
  const [isDraftSaved, setIsDraftSaved] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [image, setImage] = useState("");
  const [openofflineModal, setopenofflineModal] = useState(false);
  const [IsDisabledCheck, setIsDisabledCheck] = useState({});
  const [errorValidate, seterrorValidate] = useState({});

  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadedDocs, setUploadedDocs] = useState(selectedCustomerID.Documents || []);

  const [paymentmode, setpaymentmode] = useState("");
  const [draftIDData,setdraftIDData]= useState("")
  const [IsDisabledall, setIsDisabledall] = useState(false);
  const [alldocs, setAllDocs] = useState([]);// ALL FILES WILL BE STORED HERE IN ARRAY

  // 1. Handler function to receive the status from the child component
  const handleLinkGenerationStatus = (isGenerated) => {
    setIsDisabledall(isGenerated);
  };

  const handlepaymentMethod = (method) => {
    setpaymentmode(method);
    // If switching to offline and we have an existing draft, log this for debugging
    if (method === "offline" && draftIDData) {
      console.log("Customer switching to offline payment for existing draft:", draftIDData);
    }
  };

  const [flag, setFlag] = useState({
    mobileNo: false,
    subscriberName: false,
    gender: false,
    address1: false,
    pinCode: false,
    area: false,
    city: false,
    state: false,
    email: false,
    dob: false,
  });

  //UPLOAD DOCUMENT
  const docObjTypeId = useMemo(() => {
    return {
      29: "AAD",
      25: "PAN",
      26: "DRI",
      27: "VOT",
      28: "PAS",
    };
  }, []);


  const modalStyle = {
    position: "absolute",
    top: "40%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    borderRadius: "4px",
    border: "2px ",
    boxShadow: 24,
    p: 4,
  };
  useEffect(() => {
    // Retrieve stored data from localStorage on component load
    const storedSubscriberData =
      JSON.parse(localStorage.getItem("subscriberData")) || {};
    const storedMembershipData =
      JSON.parse(localStorage.getItem("membershipData")) || {};
    const storedNomineeData =
      JSON.parse(localStorage.getItem("nomineeData")) || {};
    const storedBankData = JSON.parse(localStorage.getItem("bankData")) || {};
    const storedGuardianData =
      JSON.parse(localStorage.getItem("guardaianData")) || {};

    // Set the retrieved data into the state
    setSubscriberData(storedSubscriberData);
    setMembershipData(storedMembershipData);
    setNomineeData(storedNomineeData);
    setBankData(storedBankData);
    setGuardianData(storedGuardianData);
  }, []);

  const validateSubscriber = () => {
    function CustomerValidation() {
      const errors = {};
      if (!subscriberData.subscriberName) {
        errors.subscriberName = "Subscriber name is required";
      }
      if (!subscriberData.gender) {
        errors.gender = "Gender is required.";
      }
      if (!subscriberData.dob) {
        errors.dob = "dob is required.";
      }
      if (!subscriberData.email) {
        errors.email = "Email ID is required.";
      } else if (!/\S+@\S+\.\S+/.test(subscriberData.email)) {
        errors.email = "Email is invalid.";
      }
      if (!subscriberData.address1.trim() && aadharverified !== 1) {
        errors.address1 = "Address is required.";
      }
      if (!/^\d{6}$/.test(subscriberData.pinCode)) {
        errors.pinCode = "Pin code is required";
      }
      if (!subscriberData.state?.length) {
        errors.state = "State is required!";
      }
      if (!subscriberData.city?.length) {
        errors.city = "city is required!";
      }
      if (!subscriberData.area?.length) {
        errors.area = "area is required!";
      }

      seterrorValidate(errors);
      return errors;
    }

    if (
      selectedCustomerID &&
      Array.isArray(selectedCustomerID) &&
      selectedCustomerID.length > 0
    ) {
      for (let i = 0; i < selectedCustomerID.length; i++) {
        if (selectedCustomerID[i]?.Isaadharverified == 1) {
          setIsDisabledCheck(subscriberData);
          return CustomerValidation();
        } else if (selectedCustomerID[i]?.customerType === "V") {
          return CustomerValidation();
        } else if (
          selectedCustomerID[i]?.Isaadharverified !== 1 &&
          selectedCustomerID[i]?.customerType !== "V"
        ) {
          return CustomerValidation();
        }
      }
    } else if (selectedOption != "withoutAadhar") {
      return CustomerValidation();
    } else if (selectedOption == "withoutAadhar") {
      return CustomerValidation();
    }

    // new minor with old phone (subscriber)
    else if (selectedId == "minor" || selectedId == "new") {
      return CustomerValidation();
    }
  };

  const validateMembership = () => {
    const errors = {};
    const { installmentAmount, minInsValue, insMultiples } = membershipData;
    if (!membershipData.selectedSchemeCode) {
      errors.selectedSchemeCode = "Scheme is required";
    } else {
      if (!installmentAmount) {
        errors.installmentAmount = "Installment amount cannot be empty";
      } else {
        // Parse installmentAmount here to ensure we're working with numbers
        const amountInt = parseInt(Number(installmentAmount, 10));
        const minAmount = parseInt(minInsValue, 10);
        const multiple = parseInt(insMultiples, 10);

        if (isNaN(amountInt)) {
          errors.installmentAmount = "Installment amount must be an integer";
        }
        if (amountInt != null && amountInt < minAmount) {
          errors.installmentAmount = `Installment amount must be at least ${minAmount}`;
        }
        if (amountInt != null && amountInt % multiple !== 0) {
          errors.installmentAmount = `Installment amount must be a multiple of ${multiple}`;
        }
      }
    }
    seterrorValidate(errors);
    return errors;
  };
  // Membership Details Validation
  const validateNominee = () => {
    const errors = {};
    if (!nomineeData.nomineename)
      errors.nomineename = "Nominee name is required";
    if (!nomineeData.relationship)
      errors.relationship = "Nominee relationship is required";
    if (!nomineeData.nomineeaddress)
      errors.nomineeaddress = "Nominee Address is required";
    if (!nomineeData.nomineephoneno)
      errors.nomineephoneno = "Nominee Phone No is required";
    seterrorValidate(errors);
    return errors;
  };
  // Bank Details Validation
  const validateBank = () => {
    const errors = {};
    if (bankData.accountNo && !/^\d{9,18}$/.test(bankData.accountNo)) {
      errors.accountNo = "Valid account number is required (9 to 18 digits).";
    }
    if (bankData.ifscCode && !/^[A-Z]{4}[0-9]{7}$/.test(bankData.ifscCode)) {
      errors.ifscCode =
        "Valid IFSC code is required (4 letters followed by 7 digits).";
    }
    seterrorValidate(errors);
    return errors;
  };

  // const SetSecondElement = () => {
  //   const element = document.querySelector(`#uploaddoc-header`);
  //   if (element) {
  //     element.scrollIntoView({
  //       behavior: "smooth",
  //       block: "start",
  //     });
  //   }
  // };



  //  else if(alldocs.length===0){
  //     toast.error("Please upload all required documents")
  //     return false;
  //   }
  // Nominee Details Validation

  const validateGuardian = () => {

    const errors = {};
    if (showGuardianDetails) {
      if (!guardaianData.guardname)
        errors.guardname = "Guardian Name is required";
      if (!guardaianData.guardrelationship)
        errors.guardrelationship = "Guardian relationship is required";
      if (!guardaianData.guarddob) {
        errors.guarddob = "Guardian DOB is required";
      } else {
        const age = calculateAge(guardaianData.guarddob);
        if (age != null && age < 18) {
          errors.guarddob = "Guardian DOB should be greater than 18.";
        }
      }
      if (!guardaianData.guardGender)
        errors.guardGender = "Guardian Gender is required.";
    }
    seterrorValidate(errors);
    return errors;
  };

  const validateAllForms = () => {
    const errors = {
      subscriber: validateSubscriber(),
      membership: validateMembership({ ...membershipData }),
      nominee: validateNominee(),
      guardian: validateGuardian(),
      bank: validateBank(),
    };

    // Ensure we only proceed with Object.keys if errors is an object
    return Object.keys(errors).reduce((acc, key) => {
      if (errors[key] && Object.keys(errors[key]).length > 0) {
        acc[key] = errors[key];
      }
      return acc;
    }, {});
  };
  const getImageUrl = (url) => {
    setImage(url);
  };
  const handleDraft = async() => {
    //  event.preventDefault();
    // alert("1 handledraft called")
    const errors = validateAllForms();

    if (Object.keys(errors).length > 0) {
      if (errors.subscriber) {
        const fieldError = Object.values(errors.subscriber)[0]; // Get the first field error
        toast.error(fieldError);
        setExpanded("subscriber-header");
        seterrorValidate(errors.subscriber);
        return;
      }
      if (errors.membership) {
        const fieldError = Object.values(errors.membership)[0]; // Get the first field error
        toast.error(fieldError);
        setExpanded("membership-header");
        seterrorValidate(errors.membership);
        return;
      }
      if (errors.nominee) {
        const fieldError = Object.values(errors.nominee)[0]; // Get the first field error
        toast.error(fieldError);
        setExpanded("nominee-header");
        seterrorValidate(errors.nominee);
        return ;
      }
      if (errors.guardian) {
        const fieldError = Object.values(errors.guardian)[0]; // Get the first field error
        toast.error(fieldError);
        setExpanded("guardian-header");
        seterrorValidate(errors.guardian);
        return;
      }
      if (errors.bank) {
        const fieldError = Object.values(errors.bank)[0]; // Get the first field error
        toast.error(fieldError);
        setExpanded("bank-header");
        seterrorValidate(errors.bank);
        return;
      }
    }
    // Proceed to save draft
    // alert("before savedraft fx")
    const docs = validatedocs();

    //  alert("docs present"+docs)
    if (docs) {
      // scro   llToTop()
      if (image) {
        // alert(" inside savedraft response to back withn draftid in handledraft 4 ")
        const draftvalue = await saveDraft();  // IN RESPONSE WE ILL GET DRAFTID number like 809 
        // alert("draftvalue in handledraft aftr  response from savedraft sending this payment 5",draftvalue)
        return draftvalue;
      } else {
        // alert("Please capture the image.");
        return false;
      }
    } else {
      return false;
    }
  };

  

  useEffect(() => {
    if (selectedCustomerID && selectedCustomerID.Documents) {
      setUploadedDocs((prevDocs) => {
        // Prevent setting state if it's already the same to avoid re-renders
        return JSON.stringify(prevDocs) === JSON.stringify(selectedCustomerID.Documents)
          ? prevDocs
          : selectedCustomerID.Documents;
      });
    } else {
      setUploadedDocs([]); // New customer case
    }
  }, [selectedCustomerID]); // Depend only on selectedCustomerID



  //UploadedFile
  const handleFileUpload = (data) => {
    setUploadedFile(data); // Store the document data
    if (data) {
      setAllDocs((prevDocs) => [
        ...prevDocs,
        {
          documentTypeId: data.docType,
          imagePath: data.documentData,
          documentNo: data.docNumber,
        },
      ]);
    }
  
    // ImagePath(documentData), Name(docNumber), Type(docType), UpdateOn
    const docObj = {};
    docObj.Name = data.docNumber;
    docObj.Type = docObjTypeId[data.docType];
    docObj.ImagePath = data.documentData;

    // setUploadedDocs([ ...selectedCustomerID.Documents, ...uploadedDocs, docObj]);
    setUploadedDocs((prev) => [...prev, docObj]);
  };
  useEffect(() => {
    console.log("uploadedDocs in mypage", uploadedDocs);
  }, [uploadedDocs]);


  useEffect(() => {
    if (paymentmode) {
      saveDraft(paymentmode);
    }
  }, [paymentmode]);

  const saveDraft = async () => {
    // alert("in savdraaft called 2")
    try {
      if (!subscriberData.mobileNo) {
        // alert(
        //   "Phone number is required. You will be redirected to the home page."
        // );
        // toast.error('Phone number is required.'); // Display error message
        navigate(`/?branch=${localStorage.getItem("decodedBranch")}`); // Navigate to the home page
        return; // Prevent saving the draft
      }
      
      if (!alldocs) {
        alert("Please upload a document.");
        return;
      }
      if (!image) {
        alert("Please capture the image.");
        return;
      }

      
      setFlag(true);
      let add1 = subscriberData.address1 || "";
      let add2 = subscriberData.address2 || "";

      const isaadharVerified = aadharverified || 0;
      const aadhar_No = aadharNo ? aadharNo : null;
      const draftData = {
        Branch: branch || membershipData.branch || "",
        Scheme: membershipData.selectedSchemeCode || "",
        Cust_Name: subscriberData.subscriberName || "",
        Gender: subscriberData.gender || "",
        Address1: add1 || "",
        Address2: add2 || "",
        Address3: subscriberData.area || "",
        State: subscriberData.state || "",
        City: subscriberData.city || "", //CITY
        Pin_Code: subscriberData.pinCode || "",
        Mobile_No: subscriberData.mobileNo || "",
        email_id: subscriberData.email || "",
        DateOf_Birth: subscriberData.dob || "",
        InstallmentAmount: membershipData.installmentAmount || "",
        NomineName: nomineeData.nomineename || "",
        NomineRelationship: String(nomineeData.relationship) || "",
        NominePhone: nomineeData.nomineephoneno || "",
        NomineAddress: nomineeData.nomineeaddress || "",
        Accountno: bankData.accountNo || "",
        ifsccode: bankData.ifscCode || "",
        GuardianName: guardaianData.guardname || "",
        GuardianRelation: guardaianData.guardrelationship || "",
        Guardiangender: guardaianData.guardGender || "",
        GuardianDOB: guardaianData.guarddob || "" ,
        IsMembershipCreated: membershipData.isMembershipCreated || "N" || "",
        MembershipNo: membershipData.membershipNo || "",
        IsAadarVerified: isaadharVerified,
        IsCancelFlag: "N",
        imageUrl: image,
        inserted_By: "BY",
        documents: alldocs,
        TnxType: paymentmode,
        AadharNo:aadhar_No
      };

      
      // alert("before api====")
      const response = await axios.post(
        `${Drafttabledb}/draftenrollment`,
        draftData,
        {
          headers: { "Content-Type": "application/json" },
        }
      );
      // alert("before api====",response)
      
      if (response.data){
        // alert(" inside savedraft response ok draftid 3 ")
        setdraftIDData(response.data.DraftID) //this is used to store  the response draftID GETTING  after saving draftenrollment 
        // alert(response.data.message); //"Draft saved successfully
        setIsDraftSaved(true);
        return response.data.DraftID; // it will return draftID NUMBER
        // setOpenModal(true);
      } else {
        alert("Server is Busy...please retry");
      }
    } catch (error) {
      alert(error.response.data.message);
      console.log(error.response.data.message);
    } finally {
      setSaveDraftTrigger(false);
    }
  };

  const handlepaymentupdate = (childfunction) => {
    // alert("handle payment ,")
    childfunction();
  };

  const handleModalClose = () => {
    setOpenModal(false);
    setopenofflineModal(false);
    clearData();
    navigate(`/?branch=${localStorage.getItem("decodedBranch")}`); // Redirect to mobile page on modal close
    //  window.location.reload();
  };

  const handleModalOenOffline = () => {

    setpaymentmode("offline");
    //setOpenModal(true);
    setopenofflineModal(true);


    // clearData();
    // navigate(`/?branch=${localStorage.getItem("decodedBranch")}`); // Redirect to mobile page on modal close
    // //  window.location.reload();
  };
  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (!isDraftSaved) {
        const message =
          "Are you sure you want to leave this page? Any unsaved changes will be lost.";
        event.preventDefault();
        event.returnValue = message;
        sessionStorage.setItem("reloading", "true");
        return message;
      }
    };

    // Add the beforeunload event listener
    window.addEventListener("beforeunload", handleBeforeUnload);

    // Cleanup the event listener when component unmounts
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isDraftSaved]);

  // Redirect to /mobile if a reload was detected
  useEffect(() => {
    if (sessionStorage.getItem("reloading") === "true") {
      sessionStorage.removeItem("reloading");
      navigate(`/?branch=${localStorage.getItem("decodedBranch")}`);
    }
  }, [navigate]);

  const clearData = () => {
    localStorage.removeItem("subscriberData"); // subscriberData
    localStorage.removeItem("membershipData");
    localStorage.removeItem("nomineeData");
    localStorage.removeItem("bankData");
    localStorage.removeItem("guardaianData");
    setSubscriberData({});
    setMembershipData({});
    setNomineeData({});
    setBankData({});
    setGuardianData({});
    setPhone("");
  };

  const clearError = (fieldName) => {
    seterrorValidate((prev) => ({
      ...prev,
      [fieldName]: undefined,
    }));
  };
  useEffect(() => {
    localStorage.setItem("subscriberData", JSON.stringify(subscriberData));
    localStorage.setItem("membershipData", JSON.stringify(membershipData));
    localStorage.setItem("nomineeData", JSON.stringify(nomineeData));
    localStorage.setItem("bankData", JSON.stringify(bankData));
    localStorage.setItem("guardaianData", JSON.stringify(guardaianData));
  }, [subscriberData, membershipData, nomineeData, bankData, guardaianData]);
  const branch1 = localStorage.getItem("decodedBranch");

  const On_click_subsriber_validation = () => {
    const errors = validateSubscriber();
    if (Object.keys(errors).length === 0) {
      showGuardianDetails
        ? setExpanded("guardian-header")
        : setExpanded("membership-header");
    } else {
      const fieldError = Object.values(errors)[0]; // Get the first error message
      toast.error(fieldError);
      setExpanded("subscriber-header");
      return true;
    }
    // SetFirstElement();
  };

  const On_click_guardian_validation = () => {
    const sub = On_click_subsriber_validation();

    if (sub) {
      setExpanded("subscriber-header");
      return;
    }
    const errors = validateGuardian();
   
    if (Object.keys(errors).length === 0) {
      setExpanded("membership-header");
    } else {
      const fieldError = Object.values(errors)[0]; // Get the first error message
      toast.error(fieldError);
      setExpanded("guardian-header");
      return true;
    }

    // SetFirstElement();
  };

  const On_click_membership_validation = () => {
    const sub = On_click_subsriber_validation();
    if (sub) {
      setExpanded("subscriber-header");
      return false;
    }
  
    const gub = On_click_guardian_validation();
    if (gub) {
      setExpanded("guardian-header");
      return;
    }
    const errors = validateMembership();
    
    if (Object.keys(errors).length === 0) {
      setExpanded("nominee-header");
    } else {
      const fieldError = Object.values(errors)[0]; // Get the first error message
      toast.error(fieldError);
      setExpanded("membership-header");
      return true;
    }
    // SetFirstElement();
  };

  const On_click_nominee_validation = () => {
    
   const sub = On_click_subsriber_validation();
    if (sub) {
      setExpanded("subscriber-header");
      return false;
    }
    const gub = On_click_guardian_validation();
    if (gub) {
      setExpanded("guardian-header");
      return false;
    }
    const meb = On_click_membership_validation();
    if (meb) {
      setExpanded("membership-header");
      return false;
    }
    const errors = validateNominee();
    if (Object.keys(errors).length === 0) {
      setExpanded("bank-header"); // Proceed to the Bank Account Details section
    } else {
      const fieldError = Object.values(errors)[0]; // Get the first error message
      toast.error(fieldError);
      setExpanded("nominee-header");

      return true;
    }
    // SetFirstElement();
  };

  const On_click_bank_validation = () => {
    const sub = On_click_subsriber_validation();
    if (sub) {
      setExpanded("subscriber-header");
      return false;
    }
    const gub = On_click_guardian_validation();
    if (gub) {
      setExpanded("guardian-header");
      return false;
    }

    const meb = On_click_membership_validation();
    if (meb) {
      setExpanded("membership-header");
      return false;
    }
    const nom = On_click_nominee_validation();
    if (nom) {
      setExpanded("nominee-header");
      return false;
    }
    const errors = validateBank(); // Validate the bank details
    if (Object.keys(errors).length === 0) {
      setExpanded("uploaddoc-header");
    } else {
      const fieldError = Object.values(errors)[0]; // Get the first error message
      toast.error(fieldError);
      setExpanded("bank-header");
      // Expand and scroll to the relevant section
      return true;
    }
    // SetSecondElement();
  };
  const validatedocs = () => {
    const sub = On_click_subsriber_validation();
    if (sub) {
      setExpanded("subscriber-header");
      return false;
    }
    const gub = On_click_guardian_validation();
    if (gub) {
      setExpanded("guardian-header");
      return false;
    }

    const meb = On_click_membership_validation();
    if (meb) {
      setExpanded("membership-header");
      return false;
    }

    const nom = On_click_nominee_validation();
    if (nom) {
      setExpanded("nominee-header");
      return false;
    }

    const bank = On_click_bank_validation();
    if (bank) {
      setExpanded("bank-header");
      return false;
    }

  // Check if any address proof document is uploaded
  const isAddressUploaded = uploadedDocs.some(
    (doc) => ["AAD", "DRI", "VOT", "PAS", "PAN"].includes(doc.Type)
  );
  
    // Only require address proof if not Aadhaar e-verified AND no documents uploaded
    if (!isAddressUploaded && aadharverified !== 1) {
      toast.error("Please Upload at least one Address Proof document");
      setExpanded("uploaddoc-header");
      return false;
    }

    // If documents are okay or Aadhaar is verified, proceed to camera
    setExpanded("camera-header");
    return true;
  };

  const On_click_payment_camera_validation = () => {
    const sub = On_click_subsriber_validation();
    if (sub) {
      setExpanded("subscriber-header");
      return false;
    }
    const gub = On_click_guardian_validation();
    if (gub) {
      setExpanded("guardian-header");
      return false;
    }

    const meb = On_click_membership_validation();
    if (meb) {
      setExpanded("membership-header");
      return false;
    }

    const nom = On_click_nominee_validation();
    if (nom) {
      setExpanded("nominee-header");
      return false;
    }

    const bank= On_click_bank_validation();
    if (bank) {
      setExpanded("bank-header");
      return false;
    }

    const doc = validatedocs();
    if (!doc) {
      setExpanded("uploaddoc-header");
      return false;
    }

    if (!image) {
      toast.error("Please capture your image.");
      setExpanded("camera-header");
      return false;
    } else {
      setExpanded("payment-header");
      return;
    }
  };

  // const On_click_uploaddoc_validation = () => {
  //   // const bnk=On_click_bank_validation()
  //   // if(bnk){
  //   //   setExpanded("bank-header")
  //   //   return
  //   // }
  //   const doc = validatedocs();
  //   SetSecondElement();
  //   // return doc
  // };

  // const On_click_camera_validation = () => {
  //   validatedocs();
  // };

  const CallModal = () => {
    // alert("calling modal")
    setOpenModal(true);
  };


  const SaveData = async() => {
   

    if(paymentmode === "online") {
      // For online payment, create new draft
      const handle = await handleDraft();
      return handle;
    }
    else if (paymentmode === "offline") {
      // Check if switching from online to offline (draft already exists)
      if (draftIDData) {
        try {
         

          // Prepare complete draft data with existing DraftID
          let add1 = subscriberData.address1 || "";
          let add2 = subscriberData.address2 || "";
          const isaadharVerified = aadharverified || 0;
          const aadhar_No = aadharNo ? aadharNo : null;
          const updateData = {
            DraftID: draftIDData, // Include existing draft ID for update
            Branch: branch || membershipData.branch || "",
            Scheme: membershipData.selectedSchemeCode || "",
            Cust_Name: subscriberData.subscriberName || "",
            Gender: subscriberData.gender || "",
            Address1: add1 || "",
            Address2: add2 || "",
            Address3: subscriberData.area || "",
            State: subscriberData.state || "",
            City: subscriberData.city || "",
            Pin_Code: subscriberData.pinCode || "",
            Mobile_No: subscriberData.mobileNo || "",
            email_id: subscriberData.email || "",
            DateOf_Birth: subscriberData.dob || "",
            InstallmentAmount: membershipData.installmentAmount || "",
            NomineName: nomineeData.nomineename || "",
            NomineRelationship: String(nomineeData.relationship) || "",
            NominePhone: nomineeData.nomineephoneno || "",
            NomineAddress: nomineeData.nomineeaddress || "",
            Accountno: bankData.accountNo || "",
            ifsccode: bankData.ifscCode || "",
            GuardianName: guardaianData.guardname || "",
            GuardianRelation: guardaianData.guardrelationship || "",
            Guardiangender: guardaianData.guardGender || "",
            GuardianDOB: guardaianData.guarddob || "",
            IsMembershipCreated: membershipData.isMembershipCreated || "N" || "",
            MembershipNo: membershipData.membershipNo || "",
            IsAadarVerified: isaadharVerified,
            IsCancelFlag: "N",
            imageUrl: image,
            inserted_By: "BY",
            documents: alldocs,
            TnxType: "offline",
            AadharNo:aadhar_No
            // Updated payment method
          };

         

          const updateResponse = await axios.post(
            `${Drafttabledb}/draftenrollment`,
            updateData,
            {
              headers: { "Content-Type": "application/json" },
            }
          );

          if (updateResponse.data) {
           

            setopenofflineModal(true);
            return draftIDData; // Return existing draft ID
          } else {
            console.error("Failed to update draft payment method");

            return false;
          }
        } catch (error) {
          console.error("Error updating draft payment method:", error);

          // Handle different types of errors
          if (error.response && error.response.data && error.response.data.message) {
            toast.error(error.response.data.message);
          } else {
            toast.error("Error updating payment method");
          }
          return false;
        }
      } else {
        // No existing draft, create new one with offline payment
        const handle = await handleDraft();
        
        if(handle) {
          setopenofflineModal(true);
        }
        return handle;
      }
    }
  };
  return (
    <Container component="main" className="mypage-header" maxWidth="md">
      <CssBaseline />
      <div className="header-container flex items-center justify-between px-4 py-3">
        <div>
          <Link to={`/?branch=${branch1}`} style={{ textDecoration: "none" }}>
            <div
              style={{
                position: "relative",
                // backgroundColor:"white",
                display: "inline-block",
                fontWeight: "bold",
              }}
            >
              <img
                src={process.env.PUBLIC_URL + "/images/bhima_logo3.png"} // Reference the image from the public folder directly
                alt="Home"
                style={{
                  width: "100px", // Adjust the size of the icon as needed
                  height: "60px", // Adjust the height accordingly
                  marginRight: "0px", // Add margin to create space between the icon and text
                  marginBottom: "15px",
                }}
              />
            </div>
          </Link>
        </div>

        <div className="flex-1 text-center">
          <h2
            className="text-black"
            style={{ fontFamily: "Quiche Sans", fontWeight: "normal" ,Color:"white"}}
          >
            ENROLLMENT
          </h2>
        </div>
      </div>

      <Box mb={2}>
        <Accordion
          expanded={expanded === "subscriber-header"}
          onChange={() =>
            setExpanded(
              expanded === "subscriber-header" ? false : "subscriber-header"
            )
          }
          sx={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="subscriber-content"
            id="subscriber-header"
          >
            <Typography sx={{ color: "#fff" }}>Subscriber Details</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Subscriberdetails
              flag={flag}
              setFlag={setFlag}
              setSubscriberData={setSubscriberData}
              newSubscriber={newSubscriber}
              errorValidate={errorValidate}
              selectedId={selectedId}
              selectedOption={selectedOption}
              customerData={customerData}
              phoneNo={phoneNo}
              clearError={clearError}
              showGuardianDetails={showGuardianDetails}
              setShowGuardianDetails={setShowGuardianDetails}
              validationdisable={IsDisabledCheck}
            />
          </AccordionDetails>
        </Accordion>
      </Box>

      {showGuardianDetails && (
        <Box mb={2}>
          <Accordion
            expanded={expanded === "guardian-header"}
            onClick={On_click_subsriber_validation}
            onChange={() =>
              setExpanded(
                expanded === "guardian-header" ? false : "guardian-header"
              )
            }
            sx={{
              background:
                "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
              color: "#fff", // Ensure text remains readable
              borderRadius: "8px", // Optional: Adds rounded corners
            }}
          >
            {/* <Accordion expanded={expanded === 'guardian-header'} onChange={() => setExpanded(expanded === 'guardian-header' ? false : 'guardian-header')}>
             */}
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="guardian-content"
              id="guardian-header"
            >
              <Typography sx={{ color: "#fff" }}>Guardian Details</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <GuardaianDetails
                setGuardianData={setGuardianData}
                errorValidate={errorValidate}
                clearError={clearError}

              />
              <div className="button-container">
                {/* <button
                  className="styled-button"
                  onClick={() => {
                    const errors = validateGuardian();
                    if (Object.keys(errors).length === 0) {
                      setExpanded('membership-header');
                    } else {
                      const fieldError = Object.values(errors)[0]; // Get the first error message
                      toast.error(fieldError);
                    }
                  }}
                >
                 <i class="bi bi-arrow-right"></i>
                </button> */}
              </div>
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      <Box mb={2}>
        <Accordion
          expanded={expanded === "membership-header"}
          onClick={On_click_guardian_validation}
          onChange={() =>
            setExpanded(
              expanded === "membership-header" ? false : "membership-header"
            )
          }
          sx={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="membership-content"
            id="membership-header"
          >
            <Typography sx={{ color: "#fff" }}>Scheme Details</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Membershipdetails
              validateMembership={validateMembership}
              setMembershipData={setMembershipData}
              membershipData={membershipData}
              branch={branch}
              errorValidate={errorValidate}
              clearError={clearError}
              isdraftid_gen={IsDisabledall}
            />
          </AccordionDetails>
        </Accordion>
      </Box>

      <Box mb={2}>
        <Accordion
          expanded={expanded === "nominee-header"}
          onClick={On_click_membership_validation}
          onChange={() =>
            setExpanded(
              expanded === "nominee-header" ? false : "nominee-header"
            )
          }
          sx={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="nominee-content"
            id="nominee-header"
          >
            <Typography sx={{ color: "#fff" }}>Nominee Details</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Nomineedeatils
              setNomineeData={setNomineeData}
              errorValidate={errorValidate}
              clearError={clearError}
              subscriberAddress={subscriberData}
              isdraftid_gen={IsDisabledall}
            />
          </AccordionDetails>
        </Accordion>
      </Box>

      <Box mb={2}>
        <Accordion
          expanded={expanded === "bank-header"}
          onClick={On_click_nominee_validation}
          onChange={() =>
            setExpanded(expanded === "bank-header" ? false : "bank-header")
          }
          sx={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="bank-content"
            id="bank-header"
          >
            <Typography sx={{ color: "#fff" }}>Bank Account Details</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Paymentdetails
              setBankData={setBankData}
              errorValidate={errorValidate}
              clearError={clearError}
            />
          </AccordionDetails>
        </Accordion>
      </Box>

      {/* Only show Upload Documents accordion if Aadhaar is NOT verified */}
      {aadharverified !== 1 && (
        <Box mb={2}>
          <Accordion
            expanded={expanded === "uploaddoc-header"}
            onClick={On_click_bank_validation}
            onChange={() =>
              setExpanded(
                expanded === "uploaddoc-header" ? false : "uploaddoc-header"
              )
            }
            sx={{
              background:
                "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
              color: "#fff", // Ensure text remains readable
              borderRadius: "8px", // Optional: Adds rounded corners
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="uploaddoc-content"
              id="uploaddoc-header"
            >
              <Typography sx={{ color: "#fff" }}>Upload Documents</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <UploadDocument
                amount={membershipData.installmentAmount}
                schemename={membershipData.selectedSchemeName}
                onFileUpload={handleFileUpload}
                uploadedDocs={uploadedDocs}
              />
            </AccordionDetails>
          </Accordion>
        </Box>
      )}

      <Box mb={2}>
        <Accordion
          expanded={expanded === "camera-header"}
          onClick={validatedocs}
          onChange={() =>
            setExpanded(expanded === "camera-header" ? false : "camera-header")
          }
          sx={{
            background: "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)", // same beige gradient
            color:"#fff",
            borderRadius: "10px",
            boxShadow: "0 2px 6px rgba(0,0,0,0.05)", // very subtle shadow
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: "#6b4a2b" }} />} // brown arrow
            aria-controls="camera-content"
            id="camera-header"
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 2,
            }}
          >
            {/* Icon Box */}
            {/* <Box
        sx={{
          width: 40,
          height: 40,
          borderRadius: "12px",
          backgroundColor: "#e5d8c7", 
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <CameraIcon sx={{ color: "#6b4a2b" }} />
      </Box> */}

            <Box>
              <Typography sx={{  color:  "#fff" }}>
                Camera
              </Typography>
              <Typography sx={{ fontSize: "14px", color:  "#fff" }}>
                Click on the Camera to Capture your Photo
              </Typography>
            </Box>
          </AccordionSummary>

          <AccordionDetails>
            <WebCamComponent getImageUrl={getImageUrl} />
          </AccordionDetails>
        </Accordion>
      </Box>


      <Box mb={2}>
        <Accordion
          expanded={expanded === "payment-header"}
          onClick={On_click_payment_camera_validation}
          onChange={() =>
            setExpanded(expanded === "payment-header" ? false : "payment-header")
          }
          sx={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="payment-content"
            id="payment-header"
          >
            <Typography sx={{ color: "#fff" }}>Payment</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Paymentgateway
              setExpanded={setExpanded}
              savedraft={SaveData}
              handlepayment={handlepaymentupdate}
              openModal={CallModal}
              paymentMethodMode={handlepaymentMethod}
              handleModalOenOffline={handleModalOenOffline}
              onLinkGenerationStatus={handleLinkGenerationStatus}
            />
          </AccordionDetails>
        </Accordion>
      </Box>



      {/* <Box mb={2}>
        <Card
          style={{
            background:
              "linear-gradient(103.45deg, rgb(97, 65, 25) -11.68%, rgb(205, 154, 80) 48.54%, rgb(97, 65, 25) 108.76%)",
            color: "#fff", // Ensure text remains readable
            borderRadius: "8px", // Optional: Adds rounded corners
          }}
        >
          <Card.Body>
            <Card.Title>Payment</Card.Title>
            <Paymentgateway
              setExpanded={setExpanded}
              savedraft={SaveData}
              handlepayment={handlepaymentupdate}
              openModal={CallModal}
              paymentMethodMode={handlepaymentMethod}
              handleModalOenOffline={handleModalOenOffline}
            />
          </Card.Body>
        </Card>
      </Box> */}

      {/* Success Modal */}
      {/* <Modal
        open={openModal}
        onClose={(event, reason) => {
          if (reason && reason === "backdropClick") return; // Prevent close on outside click
          handleModalClose(); // Only close if it's not a backdrop click
        }}
        closeAfterTransition
        className="success-model-popup2"
      >
        <Fade in={openModal}>
          <Box sx={modalStyle} class="modal-content">
            <div className="text-center">
              <div className="icon-box">
                <CheckCircleIcon sx={{ fontSize: 60, color: "green" }} />  ///////////////// Mohith_dev///////////
              </div>
            </div>
            <Typography
              variant="h6"
              component="h2"
              align="center"
              sx={{
                mt: 2,
                fontSize: { xs: "16px" },
              }}
            >
              " Thank you for Subscribing for JPP Scheme"
            </Typography>
            <Typography sx={{ mt: 2 }} align="center">
              <ul style={{ listStyleType: "none", paddingLeft: 0 }}>
                <li>Mobile No: {subscriberData.mobileNo}</li>
                <li>Subscriber Name: {subscriberData.subscriberName}</li>
                <li>Scheme Name: {membershipData.selectedSchemeName}</li>
                <li>
                  Installment Amount: ₹
                  {membershipData.installmentAmount
                    ? membershipData.installmentAmount.toLocaleString("en-IN")
                    : "N/A"}
                </li>
              </ul>
            </Typography>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                gap: "20px", // same as gap-x-5
              }}
            >
              <button
                className="custom-button1"
                style={{
                  display: "inline-block",
                  width: "100%",
                  marginTop: "20px",
                  padding: "12px",
                  borderRadius: "10px",
                  // background: "linear-gradient(90deg, #7b5ce6, #4f2dbf)",
                  color: "white",
                  textAlign: "center",
                  textDecoration: "none",
                  fontSize: "15px",
                  fontWeight: "bold",
                  cursor: "pointer",
                  boxShadow: "0px 4px 10px rgba(0,0,0,0.2)",
                }}
                onClick={handleModalClose}
              >
                OK
              </button>
            </div>
          </Box>
        </Fade>
      </Modal> */}

      <Modal
        open={openofflineModal}
        onClose={(event, reason) => {
          if (reason && reason === "backdropClick") return; // Prevent close on outside click
          handleModalClose(); // Only close if it's not a backdrop click
        }}
        closeAfterTransition
        className="success-model-popup2"
      >
        <Fade in={openofflineModal}>
          <Box sx={modalStyle} class="modal-content">
            <div className="text-center">
              <div className="icon-box">
                <CheckCircleIcon sx={{ fontSize: 60, color: "green" }} />
              </div>
            </div>
            <Typography
              variant="h6"
              component="h2"
              align="center"
              sx={{
                mt: 2,
                fontSize: { xs: "16px" },
              }}
            >
              "Thank you for your interest in the JPP Scheme. Please contact a
              Bhima agent to proceed with the payment."
            </Typography>
            <Typography sx={{ mt: 2 }} align="center">
              <ul style={{ listStyleType: "none", paddingLeft: 0 }}>
                <li>Mobile No: {subscriberData.mobileNo}</li>
                <li>Subscriber Name: {subscriberData.subscriberName}</li>
                <li>Scheme Name: {membershipData.selectedSchemeName}</li>
                <li>
                  Installment Amount: ₹
                  {membershipData.installmentAmount
                    ? membershipData.installmentAmount.toLocaleString("en-IN")
                    : "N/A"}
                </li>
              </ul>
            </Typography>
            <button className="custom-button1 w-100" onClick={handleModalClose}>
              OK
            </button>
          </Box>
        </Fade>
      </Modal>
      <ToastContainer />
    </Container>
  );
};

export default Mypage;
