
export const  CustomerMobileOTP="https://apis.bhimagold.com/api_db.js/api"
export const  Mobileverification ='https://vrudhi.bhima.info/bhimaapi/api_db.js/api/GetCustomerDetails'
export const AadharAPI="https://suvarnagopura.com/MagentoAPI/api_db.js/api"
export const PincodeAPI="https://api.postalpincode.in/pincode"
export const COLLECTION_API="https://vrudhitabenrollment.bhima.info/vrudhitabenrollmentapi/api"
export const Drafttabledb="https://vrudhitabenrollment.bhima.info/vrudhitabenrollmentapi/api"
export const BaseURL="https://vrudhicameranew.sharaanapps.co.in"

/* export const COLLECTION_API="http://localhost:9000/api"
export const Drafttabledb="http://localhost:9000/api"
export const BaseURL="http://localhost:9000/api" */


//hosted path
//123.253.10.200 (WINDOWS),(suvarnagopura) API->Draftenrollment-Sharaanapps 
//URL : https://draftenrollment.sharaanapps.co.in